--FFVII Remake Cloud version 1.0--

This skin changes Cloud's design to a Smash Bros-styled version of his FFVII Remake appearance.
The new model additions are a mix of custom assets and adapted meshes from the PS4 game (For example, his pauldron is retopo'd from the Remake model, while the belts are custom. The Buster Sword is a mix of both custom and Remake assets)
This v1 version of the mod is missing his metal finger plates, but I plan on adding those at a later date. There's some minor clipping issues too, but nothing that can't be also fixed in the future.

FFVII Remake Cloud functions as a one-slot mod, but the materia in his Buster Sword only shows up with a whole FF7R set installed. (However, AC Cloud is unaffected)
